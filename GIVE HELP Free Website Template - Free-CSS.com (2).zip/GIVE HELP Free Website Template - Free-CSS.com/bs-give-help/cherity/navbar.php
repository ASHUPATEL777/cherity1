<?php
$mainurl="http://localhost/GIVE%20HELP%20Free%20Website%20Template%20-%20Free-CSS.com/bs-give-help/blue/";
$baseurl="http://localhost/GIVE%20HELP%20Free%20Website%20Template%20-%20Free-CSS.com/bs-give-help/blue/assets";
?>
<div id="home" class="navbar navbar-default move-me ">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">
                    <img src="assets/img/logo.png" class="navbar-brand-logo " alt="">
                </a>
            </div>
            <div class="navbar-collapse collapse ">
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a href="<?php echo $mainurl;?>">HOME <i class="fa fa-bars"></i>
                            <span>Introduction</span>
                        </a>
                    </li>
                    <li class="dropdown">
                        <a href="<?php echo $mainurl; ?>/about">ABOUT <i class="fa fa-bars"></i>
                            <span>Who We Are?</span>
                        </a>
                    </li>
                    <li class="dropdown">
                        <a href="<?php echo $mainurl;?>/impact">IMPACT  <i class="fa fa-bars"></i>
                            <span>What We Done ?</span>
                        </a>
                    </li>
                    <li class="dropdown">
                        <a href="<?php echo $mainurl; ?>event">EVENTS<i class="fa fa-bars"></i>
                            <span>Recent Events</span>
                        </a>
                     </li>
                    <li class="dropdown">
                        <a href="<?php echo $mainurl; ?>registretion">ACCOUNT<i class="fa fa-bars"></i>
                            <span>sign in!</span>
                        </a>
                    </li>
                    <li class="dropdown">
                        <a href="<?php echo $mainurl;?>contactus">CONTACT <i class="fa fa-bars"></i>
                            <span>Reach us Here</span>

                    <li class="dropdown">
                <a href="<?php echo $mainurl;?>login">login<i class="fa fa-bars"></i>
                    <span>login here</span>
            
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <!--./ NAV BAR END -->