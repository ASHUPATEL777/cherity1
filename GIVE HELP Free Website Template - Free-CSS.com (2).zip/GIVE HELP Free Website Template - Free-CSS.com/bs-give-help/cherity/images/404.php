
<!--content start here-->
<div class="container mt-1 p-5">
<center>
<a href="#"><img src="<?php echo $baseurl;?>images/404.gif" class="img-fluid" style="width:60%; height: 280px; margin: auto;"></a>
<br><br>
<a href="<?php echo $mainurl; ?>"><button type="button" class="btn btn-lg" id="btn">Go to Home</button></a>

</center>  
</div>

