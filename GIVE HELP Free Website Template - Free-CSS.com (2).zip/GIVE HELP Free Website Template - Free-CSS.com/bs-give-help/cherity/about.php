<div id="about">
        <div class="container">
            <div class="row text-center" data-scroll-reveal="enter from the bottom after .3s">
                <div class="col-lg-8 col-lg-offset-2 col-md-8 col-md-offset-2 col-sm-8 col-sm-offset-2">
                    <h2>ABOUT GIVE HELP </h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit onec molestie non sem vel condimentum. Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
                </div>
            </div>
            <div class="row pad-low">
                <div class="col-lg-4 col-md-4 hover-color" data-scroll-reveal="enter from the left after .6s">
                    <div class="media">
                        <div class="pull-left">
                            <i class="fa fa-desktop fa-5x  icon-round "></i>

                        </div>
                        <div class="media-body">
                            <h3 class="media-heading">Child Care Center</h3>
                            <p>
                                Aenean faucibus luctus enim. Duis quis sem risu suspend lacinia elementum nunc. 
                                Aenean faucibus luctus enim. Duis quis sem risu suspend lacinia elementum nunc.
                            </p>

                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4" data-scroll-reveal="enter from the bottom after .9s">
                    <div class="media">
                        <div class="pull-left">
                            <i class="fa fa-paperclip fa-5x  icon-round"></i>
                        </div>
                        <div class="media-body">
                            <h3 class="media-heading">Educate Children</h3>
                            <p>
                                Aenean faucibus luctus enim. Duis quis sem risu suspend lacinia elementum nunc. 
                                Aenean faucibus luctus enim. Duis quis sem risu suspend lacinia elementum nunc.
                            </p>

                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4" data-scroll-reveal="enter from the right after .6s">
                    <div class="media">
                        <div class="pull-left">
                            <i class="fa fa-recycle fa-5x  icon-round  "></i>
                        </div>
                        <div class="media-body">
                            <h3 class="media-heading">Physical Growth</h3>
                            <p>
                                Aenean faucibus luctus enim. Duis quis sem risu suspend lacinia elementum nunc. 
                                Aenean faucibus luctus enim. Duis quis sem risu suspend lacinia elementum nunc.
                            </p>

                        </div>
                    </div>
                </div>
            </div>


        </div>
    </div>
    <!--./ ABOUT SECTION END -->
    <div class="reviews-section">
        
            <div class="container">
                <div class="row ">
                    <div class="col-lg-12 col-md-12 ">
                        <h2>DONATOR REVIEWS</h2>
                        <div id="reviews" class="carousel slide" data-ride="carousel">

                            <ol class="carousel-indicators">
                                <li data-target="#reviews" data-slide-to="0" class=""></li>
                                <li data-target="#reviews" data-slide-to="1" class=""></li>
                                <li data-target="#reviews" data-slide-to="2" class="active"></li>
                            </ol>

                            <div class="carousel-inner">
                                <div class="item">
                                    <div class="container center">
                                        <div class="col-lg-6 col-lg-offset-3 col-md-6 col-md-offset-3 slide-custom">

                                            <h4><i class="fa fa-quote-left"></i>Lorem ipsum dolor sit amet, consectetur adipiscing elit onec molestie non sem vel condimentum. <i class="fa fa-quote-right"></i></h4>

                                            <h5 class="pull-right"><strong class="c-black">Lorem Dolor</strong></h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="container center">
                                        <div class="col-lg-6 col-lg-offset-3 col-md-6 col-md-offset-3 slide-custom">
                                            <h4><i class="fa fa-quote-left"></i>Aenean faucibus luctus enim. Duis quis sem risu suspend lacinia elementum nunc. <i class="fa fa-quote-right"></i></h4>

                                            <h5 class="pull-right"><strong class="c-black">Faucibus luctus</strong></h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="item active">
                                    <div class="container center">
                                        <div class="col-lg-6 col-lg-offset-3 col-md-6 col-md-offset-3 slide-custom">
                                            <h4><i class="fa fa-quote-left"></i>Sed ultricies, libero ut  fringilla, ante elit luctus lorem, a egestas dui metus a arcu condimentum. <i class="fa fa-quote-right"></i></h4>

                                            <h5 class="pull-right"><strong class="c-black">Sed ultricies</strong></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
       
    </div>
    <!--./ REVIEWS SECTION END -->
    
    <div id="budget">
        <div class="container">
            <div class="row text-center" data-scroll-reveal="enter from the bottom after .3s">
                <div class="col-lg-8 col-lg-offset-2 col-md-8 col-md-offset-2 col-sm-8 col-sm-offset-2">
                    <h2>OUR FINIANCIAL BUDGET</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit onec molestie non sem vel condimentum. Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
                    <br />
                </div>
            </div>
            <div class="row" data-scroll-reveal="enter from the top after .6s">
                <div class="col-lg-12 col-md-12 text-center">
                    <a href="#" class="btn btn-style-4 btn-lg ">DOWNLOAD BUDGET</a>
                </div>
            </div>
        </div>
    </div>
    <!--./ BUDGET SECTION END -->
   