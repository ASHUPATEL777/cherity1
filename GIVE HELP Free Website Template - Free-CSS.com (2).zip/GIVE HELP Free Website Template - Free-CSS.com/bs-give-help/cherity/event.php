<div id="vedio-sec">
        <div class="container">
            <div class="row ">
                <div class="col-lg-6 col-md-6 col-sm-6 ">
                    <h3>How We Work ? Checkout Vedio.</h3>

                    <p data-scroll-reveal="enter from the left after 0.1s">
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                        Nulla pretium lectus vel<b> justo iaculis </b>blandit. Nulla facilisi. 
                       In hac habitasse platea dictumst. Fusce risus leo, convallis vitae bibendum in, vestibulum a tellus.
                    </p>


                    <ul>
                        <li data-scroll-reveal="enter from the left after 0.5s">
                            <b>Lorem ipsum </b>dolor sit amet, consectetur adipiscing elit.
                           Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                        </li>

                        <li data-scroll-reveal="enter from the left after 0.9s">Lorem ipsum dolor <b>sit amet, consectetur </b>adipiscing elit.
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                        </li>
                        <li data-scroll-reveal="enter from the left after 1.3s">
                            <b>Nulla lorem ipsum </b>sit amet, consectetur adipiscing elit.
                        </li>
                       
                    </ul>



                </div>

                <div class="col-lg-6 col-md-6 col-sm-6 "  data-scroll-reveal="enter from the right after .7s">

                    <iframe src="http://player.vimeo.com/video/18312392" class="vedio-style"></iframe>
                </div>

            </div>

        </div>
    </div>
    <!--./ VEDIO SECTION END -->
    <div id="recent-events">
        <div class="container">
            <div class="row text-center"  data-scroll-reveal="enter from the bottom after .5s">
                <div class="col-lg-8 col-lg-offset-2 col-md-8 col-md-offset-2 col-sm-8 col-sm-offset-2">
                    <h2>RECENT EVENTS</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit onec molestie non sem vel condimentum. Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
                </div>
            </div>
            <div class="row pad-low " data-scroll-reveal="enter from the top after .7s">
                <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12  ">
                    <div class="recent-events-wrap">
                        <img class="img-responsive" src="assets/img/portfolio/small/1.jpg" alt="">
                        <div class="overlay">
                            <div class="recent-events-inner">
                                <h3><a href="#">Consecte Adipis </a></h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit onec molestie</p>
                                <a class="preview" href="assets/img/portfolio/big/1.jpg"><i class="fa fa-eye"></i>View Event held 27 Jun 2014</a>
                            </div>
                        </div>
                    </div>
                </div>

                 <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12  ">
                    <div class="recent-events-wrap">
                        <img class="img-responsive" src="assets/img/portfolio/small/2.jpg" alt="">
                        <div class="overlay">
                            <div class="recent-events-inner">
                                <h3><a href="#">Consecte Adipis </a></h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit onec molestie</p>
                                <a class="preview" href="assets/img/portfolio/big/2.jpg" ><i class="fa fa-eye"></i>View Event held 27 Jun 2014</a>
                            </div>
                        </div>
                    </div>
                </div>

              <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12  ">
                    <div class="recent-events-wrap">
                        <img class="img-responsive" src="assets/img/portfolio/small/3.jpg" alt="">
                        <div class="overlay">
                            <div class="recent-events-inner">
                                <h3><a href="#">Consecte Adipis </a></h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit onec molestie</p>
                                <a class="preview" href="assets/img/portfolio/big/3.jpg" ><i class="fa fa-eye"></i>View Event held 27 Jun 2014</a>
                            </div>
                        </div>
                    </div>
                </div>

                 <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12  ">
                    <div class="recent-events-wrap">
                        <img class="img-responsive" src="assets/img/portfolio/small/4.jpg" alt="">
                        <div class="overlay">
                            <div class="recent-events-inner">
                                <h3><a href="#">Consecte Adipis </a></h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit onec molestie</p>
                                <a class="preview" href="assets/img/portfolio/big/4.jpg"><i class="fa fa-eye"></i>View Event held 27 Jun 2014</a>
                            </div>
                        </div>
                    </div>
                </div>

                 <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12  ">
                    <div class="recent-events-wrap">
                        <img class="img-responsive" src="assets/img/portfolio/small/5.jpg" alt="">
                        <div class="overlay">
                            <div class="recent-events-inner">
                                <h3><a href="#">Consecte Adipis </a></h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit onec molestie</p>
                                <a class="preview" href="assets/img/portfolio/big/5.jpg" ><i class="fa fa-eye"></i>View Event held 27 Jun 2014</a>
                            </div>
                        </div>
                    </div>
                </div>

                 <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12  ">
                    <div class="recent-events-wrap">
                        <img class="img-responsive" src="assets/img/portfolio/small/6.jpg" alt="">
                        <div class="overlay">
                            <div class="recent-events-inner">
                                <h3><a href="#">Consecte Adipis </a></h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit onec molestie</p>
                                <a class="preview" href="assets/img/portfolio/big/6.jpg"><i class="fa fa-eye"></i>View Event held 27 Jun 2014</a>
                            </div>
                        </div>
                    </div>
                </div>

              <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12  ">
                    <div class="recent-events-wrap">
                        <img class="img-responsive" src="assets/img/portfolio/small/7.jpg" alt="">
                        <div class="overlay">
                            <div class="recent-events-inner">
                                <h3><a href="#">Consecte Adipis </a></h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit onec molestie</p>
                                <a class="preview" href="assets/img/portfolio/big/7.jpg" ><i class="fa fa-eye"></i>View Event held 27 Jun 2014</a>
                            </div>
                        </div>
                    </div>
                </div>

                 <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12  ">
                    <div class="recent-events-wrap">
                        <img class="img-responsive" src="assets/img/portfolio/small/8.jpg" alt="">
                        <div class="overlay">
                            <div class="recent-events-inner">
                                <h3><a href="#">Consecte Adipis </a></h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit onec molestie</p>
                                <a class="preview" href="assets/img/portfolio/big/8.jpg" ><i class="fa fa-eye"></i>View Event held 27 Jun 2014</a>
                            </div>
                        </div>
                    </div>
                </div>
               
            </div>
        </div>
    </div>
    <!--./ EVENT SECTION END -->